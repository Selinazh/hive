SELECT 'Upgrading MetaStore schema from 0.10.0 to 0.11.0' AS Status from dual;
SELECT 'Finished upgrading MetaStore schema from 0.10.0 to 0.11.0' AS Status from dual;
